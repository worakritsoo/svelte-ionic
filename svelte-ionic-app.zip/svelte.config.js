// svelte.config.js
const sveltePreprocess = require('svelte-preprocess');
// const mdsvex = require('mdsvex')

module.exports = {
    preprocess: preprocess()
}