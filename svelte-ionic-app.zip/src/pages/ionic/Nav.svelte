<script>
  import NavList from "./NavList.svelte";
  import IonNav from "../../components/IonNav.svelte";
</script>

<svelte:head>
  <title>Ionic UI Companion App - Navhome</title>
</svelte:head>
<IonNav component={NavList} root="nav-list" />
