<script>
  console.log("Ionic layout");
</script>

<slot />
